#!/bin/bash  

# 检查输入参数  
if [ $# -ne 1 ]; then  
    echo "用法: $0 <可执行文件>"  
    exit 1  
fi  

EXECUTABLE="$1"  

# 检查可执行文件是否存在  
if [ ! -f "$EXECUTABLE" ]; then  
    echo "错误: 指定的可执行文件不存在"  
    exit 1  
fi  

# 获取可执行文件的目录  
EXEC_DIR=$(dirname "$EXECUTABLE")  

# 使用 ldd 获取依赖库  
ldd "$EXECUTABLE" | while read -r line; do  
    # 解析出库路径  
    LIB_PATH=$(echo "$line" | awk '{print $3}')  
    
    # 检查库路径是否存在并且是非系统库  
    if [[ -f "$LIB_PATH" && "$LIB_PATH" != /* ]]; then  
        echo "复制库: $LIB_PATH"  
        # 复制到可执行文件同根目录  
        cp "$LIB_PATH" "$EXEC_DIR"  
    fi  
done  

echo "所有非系统库已复制到 $EXEC_DIR"