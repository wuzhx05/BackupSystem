#include "config.hpp"

namespace config {
std::set <u8string> IGNORED_PATH{u8"$RECYCLE.BIN"};

}