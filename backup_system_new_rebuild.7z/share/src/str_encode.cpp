#include "str_encode.hpp"

namespace str_encode {
string to_console_format(const u8string &str) {
    return string(str.begin(), str.end());
}
u8string to_u8string(const string &str) {
    return u8string(str.begin(), str.end());
}

} // namespace str_encode