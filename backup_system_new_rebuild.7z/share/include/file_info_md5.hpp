#pragma once
#ifndef _FILE_INFO_MD5_HPP_
#define _FILE_INFO_MD5_HPP_

#include "file_info.hpp"

namespace file_info {
void calculate_md5_value(FileInfo &file);
}
#endif