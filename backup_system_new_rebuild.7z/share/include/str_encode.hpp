#pragma once
#ifndef STR_ENCODE_HPP
#define STR_ENCODE_HPP

#include <string>
#include <vector>

// to-do
namespace str_encode {
using std::string;
using std::u8string;
using std::vector;
string to_console_format(const u8string &str);
u8string to_u8string(const string &str);
// u8string utf8_to_u8string(const string &str);
// string u8string_to_utf8(const u8string &str);
}

#endif