#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>

#include "ThreadPool.hpp"
#include "env.hpp"
#include "file_info.hpp"
#include "head.hpp"
#include "print.hpp"
#include "str_encode.hpp"

int THREAD_NUM;
const string PROJECT_NAME = "backup";

vector<u8string> backup_folder_paths;
vector<u8string> directories;
vector<u8string> files;
vector<file_info::FileInfo> file_infos;

std::ofstream ofs_file_info;
std::ofstream ofs_directories;

using namespace print;

int main(int argc, char *argv[]) {
    // initialize
    env::init();
    if (!create_backup_folder(ofs_directories, ofs_file_info))
        return 1;
    if (!log(INFO, std::format("[INFO] Project started.\n"
                               "[INFO] Called time: {}\n"
                               "[INFO] UUID: {}\n",
                               env::CALLED_TIME, env::UUID)))
        return 1;

    // parse command line arguments
    vector<string> _backup_folder_paths;
    if (!parseCommandLineArgs(argc, argv, THREAD_NUM, _backup_folder_paths))
        return 1;

    // confirm backup folder paths
    cprintln(INFO, "Backup folder paths:");
    for (const auto &path : _backup_folder_paths) {
        cprintln(IMPORTANT, "  " + path);
        // to-do: any2utf8;
        backup_folder_paths.emplace_back(path.begin(), path.end());
    }
    cprintln(INFO, format("Thread number: {}{}", IMPORTANT, THREAD_NUM));
    print::pause();

    // search directories and files
    search_directories_and_files(backup_folder_paths, directories, files);

    // get file infos
    get_file_infos(files, file_infos);

    // calculate md5
    ThreadPool *pool = nullptr;
    FilesCopier *copier = nullptr;
    calculate_md5_values(pool, copier, file_infos, THREAD_NUM);

    // write to json
    write_to_json(ofs_file_info, ofs_directories, directories, file_infos);

    // copy files
    copy_files(copier);

    // check
    check(file_infos);
    return 0;
}